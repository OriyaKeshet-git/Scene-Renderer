package Geometries;

public interface FlatGeometry {
}
